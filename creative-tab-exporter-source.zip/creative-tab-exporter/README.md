# Creative Tab Exporter — Minecraft Java 1.21.11

A small **client-side Fabric mod** that exports creative-tab contents on game startup.

## Output

After launching Minecraft with the mod installed, look in the game directory for:

- `creative_tab_export/creative_tabs.txt` — readable list with tab IDs, localized names, item IDs, stack counts and displayed names.
- `creative_tab_export/creative_tabs.json` — structured data for scripts/tools.

The exporter reads the creative-tab registry from the running game, so modded tabs/items are included too. It keeps repeated entries and stack variants as separate entries rather than guessing that they are duplicates. The JSON also indicates whether a tab is currently visible in the creative menu; hidden tabs may have empty entries if Minecraft has not populated them for the current client context.

## Build

Requirements: Java 21 and Gradle 8.14.3 or compatible.

From this directory run:

```bash
gradle build
```

The mod JAR will be in `build/libs/`. Install that JAR and Fabric API into the `mods` folder of a Fabric profile running Minecraft Java 1.21.11.

## Notes

- This mod does not change gameplay and runs only on the client.
- It exports item IDs and visible stack metadata, not every data component's internal serialized payload.
