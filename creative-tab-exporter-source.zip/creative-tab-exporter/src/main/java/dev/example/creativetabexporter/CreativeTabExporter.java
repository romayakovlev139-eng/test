package dev.example.creativetabexporter;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class CreativeTabExporter implements ClientModInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger("Creative Tab Exporter");

    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            try {
                export(client.runDirectory.toPath());
            } catch (Exception exception) {
                LOGGER.error("Failed to export creative tabs", exception);
            }
        });
    }

    private static void export(Path gameDirectory) throws IOException {
        Path outputDirectory = gameDirectory.resolve("creative_tab_export");
        Files.createDirectories(outputDirectory);

        List<ItemGroup> allGroups = new ArrayList<>();
        for (ItemGroup group : Registries.ITEM_GROUP) {
            allGroups.add(group);
        }

        List<ItemGroup> visibleGroups = ItemGroups.getGroupsToDisplay();
        StringBuilder txt = new StringBuilder();
        StringBuilder json = new StringBuilder();
        json.append("{\n  \"minecraftVersion\": \"1.21.11\",\n  \"tabs\": [\n");

        int exportedTabs = 0;
        for (ItemGroup group : allGroups) {
            Identifier tabId = Registries.ITEM_GROUP.getId(group);
            if (tabId == null) continue;

            Collection<ItemStack> stacks = group.getDisplayStacks();
            boolean visible = visibleGroups.contains(group);
            String tabName = group.getDisplayName().getString();

            txt.append("[").append(tabId).append("] ").append(tabName)
                    .append(visible ? " [visible]" : " [hidden/not currently displayed]")
                    .append("\n");
            for (ItemStack stack : stacks) {
                Identifier itemId = Registries.ITEM.getId(stack.getItem());
                txt.append(itemId)
                        .append("\tcount=").append(stack.getCount())
                        .append("\tname=").append(cleanText(stack.getName().getString()))
                        .append("\n");
            }
            txt.append("\n");

            if (exportedTabs > 0) json.append(",\n");
            json.append("    {\n")
                    .append("      \"id\": ").append(jsonString(tabId.toString())).append(",\n")
                    .append("      \"name\": ").append(jsonString(tabName)).append(",\n")
                    .append("      \"visibleInCurrentCreativeMenu\": ").append(visible).append(",\n")
                    .append("      \"entryCount\": ").append(stacks.size()).append(",\n")
                    .append("      \"entries\": [");

            int entryIndex = 0;
            for (ItemStack stack : stacks) {
                Identifier itemId = Registries.ITEM.getId(stack.getItem());
                if (entryIndex++ > 0) json.append(",");
                json.append("\n        {\"id\": ").append(jsonString(itemId.toString()))
                        .append(", \"count\": ").append(stack.getCount())
                        .append(", \"name\": ").append(jsonString(stack.getName().getString()))
                        .append("}");
            }
            if (!stacks.isEmpty()) json.append("\n      ");
            json.append("]\n    }");
            exportedTabs++;
        }
        json.append("\n  ]\n}\n");

        Path txtFile = outputDirectory.resolve("creative_tabs.txt");
        Path jsonFile = outputDirectory.resolve("creative_tabs.json");
        Files.writeString(txtFile, txt.toString(), StandardCharsets.UTF_8);
        Files.writeString(jsonFile, json.toString(), StandardCharsets.UTF_8);

        LOGGER.info("Exported {} creative tabs to {}", exportedTabs, outputDirectory.toAbsolutePath());
        LOGGER.info("Files: {} and {}", txtFile.getFileName(), jsonFile.getFileName());
    }

    private static String cleanText(String value) {
        return value.replace("\\", "\\\\")
                .replace("\t", "\\t")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }

    private static String jsonString(String value) {
        StringBuilder result = new StringBuilder("\"");
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"' -> result.append("\\\"");
                case '\\' -> result.append("\\\\");
                case '\b' -> result.append("\\b");
                case '\f' -> result.append("\\f");
                case '\n' -> result.append("\\n");
                case '\r' -> result.append("\\r");
                case '\t' -> result.append("\\t");
                default -> {
                    if (c < 0x20) result.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
                    else result.append(c);
                }
            }
        }
        return result.append('"').toString();
    }
}
